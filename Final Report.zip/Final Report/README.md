
# Dental Anomaly Detection using YOLOv8 Object Detection and Segmentation

This project uses the **Tufts Dental Database: A Multimodal Panoramic X-Ray Dataset** to detect dental anomalies such as missing teeth, implants, or lesions using a YOLOv8-based pipeline combining both object detection and mask segmentation.

---

## 📦 Dataset

**Source**: [Tufts Dental Database](https://arxiv.org/abs/2312.06226)

**Details**:
- Panoramic dental X-rays (high resolution)
- Annotated anomalies under the class label: `anomaly`
- Available in YOLO format for bounding boxes and polygon format for segmentation
- Distribution visualization:

![labels.jpg](labels.jpg)

---

## 🧠 Model Pipeline

| Task               | Model     | Description                                      |
|--------------------|-----------|--------------------------------------------------|
| Object Detection   | YOLOv8    | Detect bounding boxes around anomalies          |
| Mask Segmentation  | YOLOv8-seg| Segment anomalies within detected regions       |

---

## 🏋️‍♂️ Training Overview

- **Epochs**: 200
- **Losses**: Classification, Box, Segmentation, and Distribution Focal Loss (DFL)
- Training and validation loss curves show strong convergence:

![results.png](results.png)

---

## 📊 Evaluation Metrics

### 📈 Detection and Segmentation Metrics

| Metric          | Detection (Box) | Segmentation (Mask) |
|------------------|------------------|----------------------|
| mAP@0.5          | 0.946            | 0.942                |
| F1 Score (Max)   | 0.95 @ 0.479     | 0.95 @ 0.478         |
| Precision (Max)  | 1.00 @ 0.826     | 1.00 @ 0.826         |
| Recall (Max)     | 0.95 @ 0.000     | 0.95 @ 0.000         |

---

### 📉 Precision, Recall & F1 Curves

**Bounding Box Metrics**

- F1 vs Confidence:  
  ![BoxF1_curve.png](BoxF1_curve.png)
- Precision vs Confidence:  
  ![BoxP_curve.png](BoxP_curve.png)
- Precision-Recall Curve:  
  ![BoxPR_curve.png](BoxPR_curve.png)
- Recall vs Confidence:  
  ![BoxR_curve.png](BoxR_curve.png)

**Mask Segmentation Metrics**

- F1 vs Confidence:  
  ![MaskF1_curve.png](MaskF1_curve.png)
- Precision vs Confidence:  
  ![MaskP_curve.png](MaskP_curve.png)
- Precision-Recall Curve:  
  ![MaskPR_curve.png](MaskPR_curve.png)
- Recall vs Confidence:  
  ![MaskR_curve.png](MaskR_curve.png)

---

## 📊 Confusion Matrix

- **Raw Confusion Matrix**  
  ![confusion_matrix.png](confusion_matrix.png)

- **Normalized Confusion Matrix**  
  ![confusion_matrix_normalized.png](confusion_matrix_normalized.png)

**Insights**:
- 93% of anomalies were correctly predicted.
- Background misclassifications were minimal, indicating strong class separation.

---

## 🧪 Sample Visualizations

### 📦 Ground Truth (Train)

- ![train_batch2.jpg](train_batch2.jpg)  
- ![train_batch6082.jpg](train_batch6082.jpg)

### 🧾 Ground Truth Labels (Validation)
- ![val_batch2_labels.jpg](val_batch2_labels.jpg)

### 🧠 Model Predictions (Validation)
- ![val_batch2_pred.jpg](val_batch2_pred.jpg)

---

## 💡 Key Observations

- **Excellent F1 Scores** (0.95) at moderate confidence thresholds.
- **Perfect precision** (1.0) achieved at high confidence, indicating highly trustworthy predictions.
- **High mAP@0.5** for both detection and segmentation proves the model’s capability to localize and delineate anomalies effectively.
- Confusion matrix confirms minimal false positives and false negatives.
- Label distribution is reasonably balanced and spatially consistent across the dataset.

---

## 🚀 Future Scope

- Introduce multi-label anomaly classification (e.g., caries, implants).
- Build anomaly progression tracking over time from X-ray series.
- Explore 3D reconstruction or CT-assisted learning.

---

## 🛠️ Tools & Frameworks

- **YOLOv8**: Ultralytics
- **Python**: Data preprocessing, training
- **OpenCV + Matplotlib**: Visualization
- **Pandas/Numpy**: Data analysis

---


## 📌 Conclusion

This project demonstrates the viability of deep learning-based anomaly detection in dental radiography using object detection and segmentation techniques. With near-perfect precision and robust recall, this system can significantly assist dental practitioners in early diagnosis and treatment planning.
